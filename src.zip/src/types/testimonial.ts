export type Testimonial = {
  id: string | number;
  name: string;
  designation: string;
  image: string;
  review: string;
};
