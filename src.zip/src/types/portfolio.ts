export type Portfolio = {
  id: string | number;
  title: string;
  subTitle: string;
  tags: string[];
  image: string;
};
