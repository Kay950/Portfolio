import React from "react";
import ForgetPassword from "@/components/Auth/ForgetPassword";

const ForgetPasswordPage = () => {
  return <ForgetPassword />;
};

export default ForgetPasswordPage;
