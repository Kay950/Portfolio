"use client";

import "@/styles/globals.css";

// import Footer from "@/components/Footer";

import { ThemeProvider } from "next-themes";
import { Inter } from "next/font/google";
import NextTopLoader from "nextjs-toploader";

import ToasterContext from "../context/ToastContext";
import Navbar from "@/components/MainPortfolio/Navbar";



const inter = Inter({ subsets: ["latin"] });

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={inter.className}>
        
        <ThemeProvider
          enableSystem={false}
          attribute="class"
          defaultTheme="dark"
        >
          </ThemeProvider>

        

          <div className="relative z-10">
            <NextTopLoader />
            <Navbar />
            {/* <Home /> */}
            
            {/* <Navbar />
            {children}
            <ContactPage /> */}
          </div>
          </body>
          </html>











  );}
