"use client";

import { useState } from "react";


import { motion, AnimatePresence, useInView } from "framer-motion";


export default function AboutPage() {
  


return (

    


    <main className="min-h-screen flex items-center justify-center px-6 text-white">
      <motion.section
        className="bg-black/60 p-10 rounded-lg max-w-2xl w-full"
        initial={{ opacity: 0, y: 40 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 1 }}
      >
        <h1 className="text-4xl sm:text-5xl font-extrabold mb-4 text-center">ABOUT ME</h1>
        <p className="text-zinc-400 text-center mb-8">
            A passionate Full Stack Devloper skilled with the following:
        </p>

      </motion.section>
    </main> 
    
  );

}







{/* // "use client";
// import React, { useState } from "react";
// import { motion, AnimatePresence, useInView } from "framer-motion";


// export default function About() { */}

{/* //     return ( */}
        

{/* //         <main className="flex min-h-screen flex-col items-center justify-between p-24">
//             <motion.section
//                 initial={{ opacity: 0, y: 50 }}
//                 animate={{ opacity: 1, y: 0 }}
//                 > */}

{/* //                 <h1 className="text-4xl font-bold mb-8">About Me</h1>
//                 </motion.section>


//         </main> */}





