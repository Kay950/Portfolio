"use client";
import Link from "next/link";


import { useState } from "react";

// import Navbar from "@/components/MainPortfolio/Navbar";

// export default function NavbarWrapper() {



//   return <Navbar />;
// }










// "use client";
// import Link from "next/link";



// const navItems = [
//   { name: "Home", href: "/" },
//   { name: "About", href: "/about" },
//   { name: "Contact", href: "/contact" },
// ];


// export default function Navbar() {
//   return (
//     <nav
//       className="w-full z-10 text-center"
//     >
//       <div className="space-x-4 bg-gray-800 p-4 items-center gap-6 text-sm sm:text-base object-center">
//         {navItems.map((item) => (
//           <Link 
//           key={item.name} 
//           href={item.href}

//           >
//             {item.name}
//           </Link>
//         ))}
//       </div>


//       {/* <div className="text-center p-2 bg-gray-900 text-white">
//         <Link href="/about" className=>About</Link>
//         </div> */}
//     </nav>



//   );
// }

    